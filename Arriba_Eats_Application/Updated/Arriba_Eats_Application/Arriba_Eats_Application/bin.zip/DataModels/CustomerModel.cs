﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ArribaEats.Models
{
    /// <summary>
    /// Represents a customer in the system
    /// </summary>
    public class Customer : User
    {
        #region Properties

        public Location Location { get; set; }
        public List<Order> Orders { get; set; } = new();
        public decimal TotalSpent { get; set; } = 0;

        /// <summary>
        /// Gets the total spending of the customer across all orders
        /// </summary>
        public decimal TotalSpending => Orders.Sum(o => o.TotalPrice);

        #endregion

        #region Constructor

        /// <summary>
        /// Creates a new customer with the specified details
        /// </summary>
        public Customer(string name, int age, string email, string mobile, string password, Location location)
            : base(name, age, email, mobile, password)
        {
            Location = location;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Adds an order to the customer's order history
        /// </summary>
        public void AddOrder(Order order)
        {
            Orders.Add(order);
        }

        /// <summary>
        /// Gets the customer information as a dictionary of property names and values
        /// </summary>
        public override Dictionary<string, string> GetUserInfo()
        {
            var info = base.GetUserInfo();
            info.Add("Location", Location.ToString());
            info.Add("Spending", $"You've made {Orders.Count} order(s) and spent a total of ${TotalSpending:F2}");
            return info;
        }

        #endregion
    }
}
