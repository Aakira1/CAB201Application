﻿using System.Collections.Generic;
using ArribaEats.Models;

namespace ArribaEats.Interfaces
{
    /// <summary>
    /// Interface for sorting restaurants
    /// </summary>
    public interface IRestaurantSorter
    {
        #region Sorting Method

        List<Restaurant> SortRestaurants(List<Restaurant> restaurants, Customer customer);

        #endregion
    }
}
