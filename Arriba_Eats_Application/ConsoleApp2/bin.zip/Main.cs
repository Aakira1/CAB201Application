﻿using System;
using System.ComponentModel.DataAnnotations;
using Arriba_Eats_App.Data.Models;
using Arriba_Eats_App.UI;
using Arriba_Eats_App.UI.MenuUI;
using Arriba_Eats_App.Services;
using Arriba_Eats_App.UI.MenuUI.MainMenuUI;
using System.Globalization;
using Arriba_Eats_App.Data;

namespace Main 
{
	class InitiateProgram
	{
		static void Main(string[] args)
		{
			EnhancedMenuSystem enhancedMenuSystem = new EnhancedMenuSystem(new ConsoleUI());
			enhancedMenuSystem.SetUI(new ConsoleUI());
        }
	}

	#region MenuSystem
	/// <summary>
	/// EnhancedMenuSystem class is responsible for managing the menu system of the application.
	/// </summary>
	partial class EnhancedMenuSystem
	{
		/// <summary>
		/// Constructor for EnhancedMenuSystem class.
		/// </summary>
		/// <param name="UI"></param>
		public EnhancedMenuSystem(IUserInterface UI = null!)
		{
			UI = UI ?? UIService.Current!; // Use the default UI if none is provided
		}

        /// <summary>
        /// SetUI method is responsible for setting the user interface for the application.
        /// </summary>
        /// <param name="testUI"></param>
        public void SetUI(IUserInterface UI)
		{
			UIService.SetUserInterface(UI);
        }
	}
	#endregion
}